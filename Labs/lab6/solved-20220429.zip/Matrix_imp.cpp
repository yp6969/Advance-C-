#include<algorithm>

template<class T>
class Matrix {
     std::array<int,2> dim;
     T* elem; // pointer to size() elements of type T
public:
	Matrix(int d1, int d2) :dim{d1,d2}, elem{new T[d1*d2]} { }
    
	int size() const { return dim[0]*dim[1]; }
	
	/* copy constructor */
     Matrix(const Matrix& m) :  dim{m.dim}, elem{new T[m.size()]} {
		std::copy(m.elem,m.elem+m.size(),elem); 
	 }
	 
     /* move constructor */
	Matrix(Matrix&& a) : dim{a.dim}, elem{a.elem}     // grab a's representation (!)
	{
       a.dim = {0,0};                // clear a's representation
       a.elem = nullptr;
	}
                  
	 /* copy assignment */
    Matrix& operator=(const Matrix& m) { 
	 if (dim[0]!=m.dim[0] || dim[1]!=m.dim[1])
        throw runtime_error("bad size in Matrix =");
    std::copy(m.elem,m.elem+m.size(),elem);     // copy elements (space is already allocated)
	/* Alternative:
	  Matrix tmp {m};         // make a copy
      std::swap(tmp,*this);        // swap tmp's representation with *this's
	  */
     return *this;
    }

    /* move assignment */
	Matrix& operator=(Matrix&& a) {
	   std::swap(dim,a.dim);            // swap representations
       std::swap(elem,a.elem);
	   return *this;
	}

	~Matrix() { delete[] elem; }

	friend Matrix operator+(const Matrix& a, const Matrix& b);

};
 Matrix& operator=(Matrix&& a) { //dim is a non-aggregate / object
	 this->dim = std::move(a.dim);


Matrix(Matrix&& a) : dim{std::move(a.dim)}, elem{a.elem}





Matrix operator+(const Matrix& a, const Matrix& b) {
     if (a.dim[0]!=b.dim[0] || a.dim[1]!=b.dim[1])
            throw std::runtime_error("unequal Matrix sizes in +");
     Matrix res{a.dim[0],a.dim[1]};
     constexpr auto n = a.size();
     for (int i = 0; i!=n; ++i)
           res.elem[i] = a.elem[i]+b.elem[i];
     return res; // move semantics takes care of efficiency
}